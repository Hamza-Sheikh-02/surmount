import React from "react";
import HeroSection from "@/components/HeroSection";

const Home: React.FC = () => {
  return (
    <div>
      <HeroSection/>
    </div>
  );
};

export default Home;
