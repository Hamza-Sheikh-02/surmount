import CollectionsSection from "@/components/CollectionsSection";

const CollectionsPage = () => {
  return <CollectionsSection />;
};

export default CollectionsPage;
